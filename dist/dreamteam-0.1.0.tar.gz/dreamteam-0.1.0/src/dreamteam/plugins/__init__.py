# Plugins externes pour DreamTeam
# Ce package contient les plugins enregistrés via entry_points
